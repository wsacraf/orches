/// <reference lib="webworker" />


// ****************************************************************** Worker Bridge
// self is a keyword: Reference to this Worker 
self.onmessage = HandleWork;

function CallBack(message) {
  self.postMessage({ message: message.message, data: message.data, source: message.sourceSection });
  self.close();
}

// ****************************************************************** Worker Body
function HandleWork(data: any) {
  switch (data.data.message) {
    case 'runSection':
      executeSection(data.data.message, data.data.data, data.data.fromSection);
      break;
    case 'runAll':
      executeAll(data.data.message, data.data.data);
      break;
    case 'executeSelected':
      executeSelected(data.data.message, data.data.data);
      break;
    case 'executeFabric':
      executeFabric(data.data.message, data.data.data);
      break;
  }

}

function executeSection(message, sectionData, fromSection) {
  let executeSectionData = [];
  let data = [];
  Object.keys(sectionData.data).forEach(item => {
    data.push({
      fabric: sectionData.fabric,
      name: item,
      data: sectionData.data[item]
    });
  })
  setTimeout(() => {
    data.forEach(element => {
      element.data.status = "Complete";
      executeSectionData.push(element);
    });
    CallBack({ message: message, data: executeSectionData, sourceSection: fromSection });
  }, 10000);
}

function executeAll(message, allData) { }

function executeSelected(message, selectedWorkflows) {
  executeFabricOrSelected(message, selectedWorkflows);
}

function executeFabric(message, fabricData) {
  executeFabricOrSelected(message, fabricData);
}

function executeFabricOrSelected(message, fabricData) {
  let orchWorker = [];
  let orchWorkermainData: any;
  orchWorkermainData = fabricData;
  setTimeout(() => {
    for (let i = 0; i <= 30; i++) {
      if (i === 30) {
        orchWorkermainData.forEach(element => {
          element.data.status = "Complete";
          orchWorker.push(element);
        });
      }
    }
    CallBack({ message: message, data: orchWorker });
  }, 10000);
}


