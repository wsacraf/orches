import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'app-details-body',
  templateUrl: './details-body.component.html',
  styleUrls: ['./details-body.component.css'],
  animations: [
    trigger('teda', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('0.25s', style({ opacity: 1 })),
      ])
    ])
  ]
})
export class DetailsBodyComponent implements OnInit {

  @ViewChild("consoleWindow") consoleWindow: ElementRef;

  public section: any;
  public fabrics: Array<any>;
  public component: string;
  public tasks: Array<any>;
  public selectedWorkflows: Array<any>;
  public isExecutionOn: boolean;
  public filtersOn: boolean;

  private workerResponse: Array<any>;
  private output: any;
  private webWorker: Worker;

  @Input() set sectionData(data: any) {
    this.section = data;
    this.extractFabrics(data.sectionData.components);
    this.generateTasks(data, this.fabrics[0].originalItem);
  };

  @Output() closeSignal = new EventEmitter<boolean>();

  constructor() {
    this.fabrics = [];
    this.tasks = [];
    this.selectedWorkflows = [];
    this.workerResponse = [];
  }

  ngOnInit() {
    this.fabrics[0].isActive = true;
  }

  public expandFilters() {
    this.filtersOn = !this.filtersOn;
  }

  public closeSection() {
    this.closeSignal.emit(false);
  }

  public selectTask(task) {
    this.fabrics.forEach(item => {
      if (item.originalItem === task.fabric) {
        task.isChecked = !task.isChecked;
        if (task.isChecked) {
          this.selectedWorkflows.push(task);
        } else {
          this.selectedWorkflows.splice(this.selectedWorkflows.indexOf(task), 1);
        }
        this.selectedWorkflows.length > 0 ? item.isWorkflowSelected = true : item.isWorkflowSelected = false;
      }
    })
  }

  private extractFabrics(components) {
    Object.keys(components).forEach(item => {
      this.fabrics.push({
        isWorkflowSelected: false,
        originalItem: item,
        displayName: item.substr(-2)
      });
      this.component = item.split(' ')[0];
    })
  }

  public fabricSelection(fabric) {
    this.fabrics.forEach(item => {
      item.isWorkflowSelected = false;
      item.isActive = false;
    })
    this.generateTasks(this.section, fabric.originalItem);
    return fabric.isActive = true;
  }

  public executeAllWorkflows() {
    this.isExecutionOn = true;
    // this.consoleWindow.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start', inline: "start" });
    this.tasks.forEach(wf => {
      wf.data.status = 'In Progress'
    })
    this.checkWorker();
    this.webWorker.postMessage({ message: 'executeFabric', data: this.tasks });
  }

  public executeSelectedWorkflows() {
    this.isExecutionOn = true;
    this.selectedWorkflows.forEach(wf => {
      wf.data.status = 'In Progress'
    })
    this.checkWorker();
    if (this.selectedWorkflows.length > 0) {
      this.webWorker.postMessage({ message: 'executeSelected', data: this.selectedWorkflows });
    }
  }

  private checkWorker() {
    if (typeof Worker !== 'undefined') {
      this.webWorker = new Worker('../orch.worker', { type: 'module' });
      this.webWorker.addEventListener('message', (evt: MessageEvent) => {
        this.compareValues(evt.data);
      })
    }
  }

  private compareValues(workerResponse) {
    if (workerResponse.message === 'executeAll') {
      this.workerResponse.push(workerResponse.data);
    }
    workerResponse.data.forEach(dataItem => {
      this.tasks.find(item => {
        if (item.fabric === dataItem.fabric && item.name === dataItem.name) {
          return item.data.status = dataItem.data.status
        }
      })
    });
  }

  private generateTasks(data, index) {
    const tasks = [];
    this.tasks = [];
    Object.keys(data.sectionData.components[index].tasks.allTasks).forEach(item => {
      tasks.push({
        fabric: index,
        name: item,
        data: data.sectionData.components[index].tasks.allTasks[item]
      });
    });
    this.tasks = tasks;
    this.compareReplaceValues();
  }

  private compareReplaceValues() {
    this.workerResponse.forEach(workerRes => {
      workerRes.forEach(element => {
        if(this.tasks.indexOf(element)) {
          this.tasks.find(item => {
            if (item.fabric === element.fabric && item.name === element.name) {
              return item.data.status = element.data.status;
            }
          });
        }
      });
    })
  }

}
