import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsBodyComponent } from './details-body.component';

describe('DetailsBodyComponent', () => {
  let component: DetailsBodyComponent;
  let fixture: ComponentFixture<DetailsBodyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailsBodyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsBodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
