import { FabricPipe } from './fabric.pipe';

describe('FabricPipe', () => {
  it('create an instance', () => {
    const pipe = new FabricPipe();
    expect(pipe).toBeTruthy();
  });
});
