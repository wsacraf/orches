import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fabric'
})
export class FabricPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
