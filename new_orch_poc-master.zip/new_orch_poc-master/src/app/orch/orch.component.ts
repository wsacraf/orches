import { Component, OnInit } from '@angular/core';
import { OrchServService } from '../service/orch-serv.service';
import { ExecutionServiceService } from '../execution-service.service';

@Component({
  selector: 'orch',
  templateUrl: './orch.component.html',
  styleUrls: ['./orch.component.css'],
  providers: [OrchServService, ExecutionServiceService],
})
export class OrchComponent implements OnInit {

  public sections: Array<any>;
  public dynamicHeight: any;
  public xPos: number;
  public detailsBodyIsOn: boolean;
  public selectedSection: any;
  public sectionExpanded: boolean;
  public dynamicWidth: any;

  private isSectionAlreadyExpanded: boolean;

  constructor(private orchServService: OrchServService, private executionServiceService: ExecutionServiceService) {
    this.sections = [];
    this.executionServiceService.sendWorkerResponse.subscribe(response => {
      console.log(response)
      if (Object.keys(response).length > 0) {
        this.sections.forEach(item => {
          if (response.source === item.sectionTitle) {
            console.log(response.source, item.sectionTitle)
            return item.isExecuting = false;
          }
        })
      }
    });
  }

  ngOnInit(): void {
    this.orchServService.getData().subscribe(data => {
      const orchData = data['Management Network'];
      Object.keys(orchData.sections).forEach(item => {
        if (item.includes('Management Switches')) {
          let assetTypes = [];
          let totalWorkflows: Array<number> = [];
          Object.keys(orchData.sections[item].components).forEach(compItem => {
            assetTypes.push(orchData.sections[item].components[compItem].assetType);
            totalWorkflows.push(Object.keys(orchData.sections[item].components[compItem].tasks.allTasks).length);
          })
          const sectionTitle = item.split('Management Switches - ')[1];
          this.sections.push({
            sectionTitle: sectionTitle,
            sectionData: orchData.sections[item],
            totalComponents: Object.keys(orchData.sections[item].components).length,
            assetTypes: Array.from(new Set(assetTypes)),
            totalWorkflows: totalWorkflows.reduce(function (a, b) {
              return a + b
            })
          });
        }
      })
    })
  }

  public expandSection(section, target) {
    this.sectionExpanded = true;
    this.sections.forEach(item => {
      item.detailsBodyIsOn = false;
      item.dynamicHeight = 'auto';
    })
    this.selectedSection = section;
    section.dynamicHeight = '100%';
    section.detailsBodyIsOn = true;
    this.setDynamicWidth();
    this.scrollTo(target);
  }

  private setDynamicWidth() {
    let secRpt = document.getElementById('sectionRepeat');
    let sectioncard = document.getElementById('card');
    if (this.isSectionAlreadyExpanded) {
      this.dynamicWidth = ((secRpt.offsetWidth / 16) - ((sectioncard.offsetWidth * 5 / 16) - 0.65)) + 'rem';
    } else {
      this.dynamicWidth = ((secRpt.offsetWidth / 16) - ((sectioncard.offsetWidth * 5 / 16) - 0.5)) + 'rem';
      this.isSectionAlreadyExpanded = true;
    }
  }

  private scrollTo(event) {
    let cardBody = document.getElementById('cardBody');
    cardBody.scrollTo({
      top: cardBody.offsetHeight - event.pageY,
      left: 0,
      behavior: "smooth"
    });
  }

  public closeSection() {
    this.sections.forEach(item => {
      item.detailsBodyIsOn = false;
    })
  }

  public catchSignal(signal: boolean) {
    this.isSectionAlreadyExpanded = signal;
    this.sectionExpanded = signal;
    this.sections.forEach(item => {
      item.detailsBodyIsOn = signal;
      item.dynamicHeight = 'auto';
    })
  }

  public runSection(sectionData) {
    let widthIncrement = 0;
    sectionData.progressingWidth = '';
    sectionData.isExecuting = true;
    this.executionServiceService.runSection(sectionData);
    setInterval(() => {
      sectionData.progressingWidth = (widthIncrement+=10) + '%';
    }, 1000)
    return sectionData;
  }

}
