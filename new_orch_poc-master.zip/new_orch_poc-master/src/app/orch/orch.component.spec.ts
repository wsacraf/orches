import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrchComponent } from './orch.component';

describe('OrchComponent', () => {
  let component: OrchComponent;
  let fixture: ComponentFixture<OrchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
