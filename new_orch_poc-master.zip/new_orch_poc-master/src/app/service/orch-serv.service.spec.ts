import { TestBed } from '@angular/core/testing';

import { OrchServService } from './orch-serv.service';

describe('OrchServService', () => {
  let service: OrchServService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OrchServService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
