import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExecutionServiceService {

  private webWorker: Worker;
  public sendWorkerResponse: Subject<any> = new Subject();

  constructor() {
  }

  public runSection(section: any) {
    let tasks = [];
    Object.keys(section.sectionData.components).forEach(item => {
      tasks.push({
        fabric: item,
        name: section.sectionData.components[item].title,
        data: section.sectionData.components[item].tasks.allTasks
      });
    })
    for (let idx = 0; idx < Object.keys(section.sectionData.components).length; idx++) {
      this.checkWorker();
      this.webWorker.postMessage({ message: 'runSection', data: tasks[idx], fromSection: section.sectionTitle })
    }
  }

  public runAll(allData: any) {
    return;
  }

  private checkWorker() {
    if (typeof Worker !== 'undefined') {
      this.webWorker = new Worker('./orch.worker', { type: 'module' });
      this.webWorker.addEventListener('message', (evt: MessageEvent) => {
        this.sendResponseBack(evt);
      })
    }
  }

  private sendResponseBack(evt) {
    let responseObj = {
      source: evt.data.source,
      data: evt.data.data,
      message: evt.data.message
    }
    this.sendWorkerResponse.next(responseObj);
  }

}
